console.log("loading module c")

for (let i = 0; i < 1_000_000_000; i ++);

console.log("end module c")
