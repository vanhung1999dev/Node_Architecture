console.log("--Begin module c")
for (let i= 0; i < 100000000; i ++);
console.log("--End Module c")

const test = {"test":"testc"} 
export default test;
