console.log("--Begin module d")
for (let i= 0; i < 100000000; i ++);
console.log("--End Module d")

const test = {"test":"testd"} 
export default test;
