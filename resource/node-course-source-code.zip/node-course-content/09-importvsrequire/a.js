console.log("--Begin module a")
for (let i= 0; i < 100000000; i ++);
console.log("--End Module a")

const test = {"test":"testa"} 
export default test;
