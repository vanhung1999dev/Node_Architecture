console.log("--Begin module b")
for (let i= 0; i < 100000000; i ++);
console.log("--End Module b")

const test = {"test":"testb"} 
export default test;
